    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="/js/tailwind.config.js"></script>
<style>
    .sticky-footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    background-color: #ffffff; /* You can change the background color as needed */
    border-top: 1px solid #e0e0e0; /* Optional: Add a border at the top of the footer */
    padding: 10px 0; /* Optional: Add padding to the footer content */
    box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.1); /* Optional: Add a shadow at the bottom */
}
</style>